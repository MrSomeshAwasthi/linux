/*
============================================================================
Name : 2.c
Author : Somesh Awasthi
Description :Write a simple program to execute in an infinite loop 
at the background. Go to /proc directory and identify all the process 
related information in the corresponding proc directory.
Date: 28th Aug, 2023.
============================================================================
*/
#include<stdio.h>
int main()
{
		while(1)
		{
			
		}
	return 0;
}
