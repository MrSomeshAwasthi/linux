#include<stdio.h>
int main(){
    printf("extra\n");
}